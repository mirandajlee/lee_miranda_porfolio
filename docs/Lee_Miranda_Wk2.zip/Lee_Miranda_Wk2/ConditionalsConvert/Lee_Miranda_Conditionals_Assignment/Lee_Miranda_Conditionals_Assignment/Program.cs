﻿using System;

namespace Lee_Miranda_Conditionals_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/* Miranda Lee
			 * Section 02
			 * November 8 2015
			 * Conditionals Assignment
			 */

			//If you can buy new makeup after paycheck or not
			//Prompt for name
			Console.WriteLine ("Hello! What is your name?");
			 
			//capture user response
			string userName = Console.ReadLine ();

			//Say Hello to user and ask if they like makeup
			Console.WriteLine ("Nice to meet you " + userName + "! Do you have an obsession with makeup? Enter yes or no.");

			//Capture user response
			string likeMakeupString = Console.ReadLine ();

		
			//start conditional 1
			if (likeMakeupString == "no") {
				Console.WriteLine ("Well then, it looks like we are done here.");
				
			} else {

			//Tell user what we are doing and ask for paycheck amount. 

			Console.WriteLine ("Let's see if you can buy the new Kat Von D Makeup Palette! \r\n How much was your paycheck?");

				//Capture the user response
				string paycheckString = Console.ReadLine (); 

				//create variable to hold the output
				int paycheck;

				//Convert the user response if they did not enter only integers

				if(!(int.TryParse(paycheckString, out paycheck))){

					//Tell the user the problem and ask for correction
					Console.WriteLine ("It looks like you typed in something other than integers, please type only integers.");
					paycheckString = Console.ReadLine ();
					int.TryParse (paycheckString, out paycheck);

				}

				//find the amount of bills
				Console.WriteLine ("You've been working hard! How much are your bills?");

				//capture the user response
				string billsString = Console.ReadLine ();

				//create variable to hold the output
				int bills;

				//Convert the user response if they did not enter only integers

				if (!(int.TryParse (billsString, out bills))) {

					//Tell the user the problem and ask for correction
					Console.WriteLine ("It looks like you typed in something other than integers, please type only integers.");
					billsString = Console.ReadLine ();
					int.TryParse (billsString, out bills);
				}

				//find out how much they have left over after bills
				int spendingMoney = paycheck - bills;

				//Start Conditional #2
				//We can buy the Makeup palette if the paycheck is $1000 or more, and the bills are $700 or less.
				if (paycheck >= 1000 && bills <= 700) {

					//Tell the user that they get to go get the Makeup Palette!
					Console.WriteLine ("Get on over to your nearest Sephora! You have an extra $" + spendingMoney + " to spend!");
			
					//The bills are tight, but it would be possible to buy the Palette.
				} else if (paycheck >= 500 && bills <= 400) {

					//Tell the user that they have a tight budget but could still be able to get the palette
					Console.WriteLine ("You only have $" + spendingMoney + " after your bills, but you can still afford the palette!");

					//Tell the user that they cannot afford the palette right now.
				} else {

					Console.WriteLine ("It looks like your budget is too tight right now, save up and pick up that palette ASAP!");

				}

			}
		

			/*End of Calculator
			 * I entered my name, followed by no, so the rest of the code was skipped over.
			 * I entered my name and then followed by yes, I then entered 1000 for my paycheck, 200 for my bills. I got that I can buy the palette.
			 * I entered my name and then followed by yes, I then entered 300 for my paycheck and 200 for my bills. I got that I cannot afford the palette.
			 * I entered my name, then yes, then I entered kkk and it prompted me to enter only integers, I entered 500 and then 
			 * it asked for bills I again entered kkk and then it prompted me for integers again. I entered 100 and then it told me that I could afford the palette.


			*/
}
	}
}
