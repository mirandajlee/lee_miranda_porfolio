﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE08
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] myArray = new string[10]{"Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Moore", "Taylor", "Anderson"};
            Boolean TrueBool = true;
            Boolean falseBool = false;
            


            Console.WriteLine("Before sort: \r\n");
            foreach (var item in myArray)
            {
                Console.WriteLine(item);
            }

           arraySort(myArray, TrueBool);

            Console.WriteLine("\r\nAfter Ascending sort: \r\n");
            foreach (var item in myArray)
            {
                Console.WriteLine(item);
            }

            arraySort(myArray, falseBool);

            Console.WriteLine("\r\nAfter Descending sort: \r\n");
            foreach (var item in myArray)
            {
                Console.WriteLine(item);
            }


            Console.ReadLine();

        }
      

        static void arraySort(string[] array, Boolean mybool)
        {
            int i, j;

            //ascending
            if (mybool== true)
            {
                for (i = 1; i < array.Length; i++)
                {
                    string value = array[i];
                    j = i - 1;
                    while ((j >= 0) && (array[j].CompareTo(value) > 0))
                    {
                        array[j + 1] = array[j];
                        j--;
                    }
                    array[j + 1] = value;
                }
            }
            //descending
            else 
            {

                for (i = 0; i < array.Length; i++)
                {
                    string value = array[i];
                    j = i - 1;
                    while ((j >= 0) && (array[j].CompareTo(value) < 0))
                    {
                        array[j + 1] = array[j];
                        j--;
                    }
                    array[j + 1] = value;
                }
            }
        }






    }
}
