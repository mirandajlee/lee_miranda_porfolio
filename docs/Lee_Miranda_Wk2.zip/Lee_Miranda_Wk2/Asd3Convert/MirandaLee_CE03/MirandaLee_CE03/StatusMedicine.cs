﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    class StatusMedicine : Item
    {

         static int intEffect;
         static string strEffect;
         static string description;
        public static int characterHealth;



        public override void use(Character mainCharacter)
        {
           characterHealth = intEffect + Character.health;
        }

        public StatusMedicine(int _intEffect, string _strEffect, string _description)
        {
            intEffect = _intEffect;
            strEffect = _strEffect;
            description = _description;
        }
    }
}
