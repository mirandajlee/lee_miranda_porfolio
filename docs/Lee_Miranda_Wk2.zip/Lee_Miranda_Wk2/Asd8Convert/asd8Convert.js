var myArray = ["Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Moore", "Taylor", "Anderson"];
var TrueBool = true;
var falseBool = false;
var index;


console.log("Before sort: \r\n");
for (index = 0; index < myArray.length; ++index) {
    console.log(myArray[index]);
}


ArraySort(myArray, TrueBool);
console.log("\rAfter Ascending sort: \r");
for (index = 0; index < myArray.length; ++index) {
    console.log(myArray[index]);
}


ArraySort(myArray, falseBool);

console.log("\rAfter Descending sort: \r");
for (index = 0; index < myArray.length; ++index) {
    console.log(myArray[index]);
}







function ArraySort(array,mybool)
{
    var i, j;
    var length = array.length;

    //ascending
    if (mybool== true)
    {
        for (i = 1; i < length; i++)
        {
            var value = array[i];
         for(j = i-1; j>=0 && (array[j]>value); j--)    {

                array[j + 1] = array[j];

            }
            array[j + 1] = value;
        }
    }
    //descending
    else
    {

        for (i = 0; i < length; i++)
        {
             value = array[i];
            j = i - 1;
            for(j - i-1; j>=0 && (array[j]<value); j--){

                array[j + 1] = array[j];

            }
            array[j + 1] = value;
        }
    }
}

