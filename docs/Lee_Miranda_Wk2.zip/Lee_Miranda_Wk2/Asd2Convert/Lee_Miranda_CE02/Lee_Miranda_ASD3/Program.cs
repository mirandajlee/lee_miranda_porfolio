﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lee_Miranda_ASD3
{
    class Program
    {

        private static int attack;
        private static string weaponName;
        private static string name;
        private static int baseAttack;
        private static int health;
        private static int age;
        private static string gender;
        private static string userChoice;
        


        //static character 
        private static character baseCharacter;


        public static void Main(string[] args)
        {

            int intUserChoice;

            //User options

            while (userChoice != "exit")
            {
                Console.WriteLine("Would you like to: \r\n 1.) Create a character \r\n 2.) Modify Character \r\n 3.) Create and Equip Weapon \r\n 4.) Display Character Data \r\n 5.) Exit \r\n Enter the corresponding number or the choice.");
                userChoice = Console.ReadLine();
                Int32.TryParse(userChoice, out intUserChoice);



                if (string.Compare(userChoice, "Create a character", true) == 0)
                {
                    createCharacter();
                }
                if(intUserChoice == 1)
                {
                    createCharacter();
                }
                else if (string.Compare(userChoice, "Modify Character", true) == 0)
                {
                    modifyCharacter();
                }
                else if (intUserChoice == 2)
                {
                    modifyCharacter();
                }
                else if (string.Compare(userChoice, "Create and equip weapon", true) == 0)
                {
                    newWeapon();
                }
                else if (intUserChoice == 3)
                {
                    newWeapon();
                }
                else if (string.Compare(userChoice, "Display Character Data", true) == 0)
                {
                    displayCharacter();
                }
                else if (intUserChoice == 4)
                {
                    displayCharacter();
                }

                else if (string.Compare(userChoice, "Exit", true) == 0)
                {
                    Environment.Exit(0);
                        
                }
                else if (intUserChoice == 5)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Please enter the choice or the correlated number, and press enter");
                }

            }
        }

        //functions

        //create new character

        public static void createCharacter()
        {

            Console.Write("What is the name of your character?");
            name = Console.ReadLine();

            Console.Write("What is the baseAttack of your character?");
            string baseAttackString = Console.ReadLine();

            while (!int.TryParse(baseAttackString, out baseAttack))
            {
                Console.WriteLine("Please type only integers, then press enter.");
                baseAttackString = Console.ReadLine();
            }

            

            Console.Write("What is the health of your Character?");
            string healthString = Console.ReadLine();

            while (!int.TryParse(healthString, out health))
            {
                Console.WriteLine("Please type only integers, then press enter.");
                healthString = Console.ReadLine();
            }

            Console.Write("What is the age of your character?");
            string ageString = Console.ReadLine();

            while (!int.TryParse(ageString, out age))
            {
                Console.WriteLine("Please type only integers, then press enter.");
                ageString = Console.ReadLine();
            }

            Console.Write("What is the gender of your character?");
            gender = Console.ReadLine();

            character mainCharacter = new character(name, baseAttack, health, age, gender);

            
            baseCharacter = mainCharacter;


            Console.WriteLine(" ");
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        

    }


    //create new weapon

        public static void newWeapon() {

            

             Console.Write("What is the attack of your new Weapon?");
            string attackString = Console.ReadLine();

            while (!int.TryParse(attackString, out attack))
            {
                Console.WriteLine("Please type only integers, then press enter.");
                attackString = Console.ReadLine();
            }

            Console.Write("What is the name of your new weapon?");
            weaponName = Console.ReadLine();

            weapon newWeapon = new weapon(attack, weaponName);

            newWeapon.setWeaponName(weaponName);
           

            



            Console.WriteLine("The " + weaponName + " is the equipped weapon.");

            


            Console.WriteLine(" ");
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        

    }

        public static void modifyCharacter()
        {
            string modifyResponse;
            int intModifyResponse;

            if (baseCharacter == null)
            {
                Console.WriteLine("The Character does not currently exist.");
            }
            else

            {
                Console.WriteLine("Which option would you like to modify for"+name+ "? \n 1- Name \n 2- baseAttack \n 3- health \n 4- age \n 5- gender");
                modifyResponse = Console.ReadLine();
                Int32.TryParse(modifyResponse, out intModifyResponse);


                switch (modifyResponse)
                {
                    case "Name":

                        Console.WriteLine("What would you like the new name to be?");
                        name = Console.ReadLine();


                        break;
                    case "baseAttack":
                        Console.WriteLine("What would you like the new baseAttack to be?");
                        string baseAttackString = Console.ReadLine();

                        while (!int.TryParse(baseAttackString, out baseAttack))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            baseAttackString = Console.ReadLine();
                        }

                        break;
                    case "health":
                        Console.WriteLine("What would you like the new health to be?");
                        string healthString = Console.ReadLine();

                        while (!int.TryParse(healthString, out health))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            healthString = Console.ReadLine();
                        }


                        break;
                    case "age":
                        Console.WriteLine("What would you like the new age to be?");
                        string ageString = Console.ReadLine();

                        while (!int.TryParse(ageString, out age))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            ageString = Console.ReadLine();
                        }



                        break;
                    case "gender":
                        Console.WriteLine("What would you like the new gender to be?");
                        gender = Console.ReadLine();

                        break;
                }

                switch (intModifyResponse)
                {
                    case 1:
                        Console.WriteLine("What would you like the new name to be?");
                        name = Console.ReadLine();

                        break;
                    case 2:
                        Console.WriteLine("What would you like the new baseAttack to be?");
                        string baseAttackString = Console.ReadLine();

                        while (!int.TryParse(baseAttackString, out baseAttack))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            baseAttackString = Console.ReadLine();
                        }
                        break;


                    case 3:
                        Console.WriteLine("What would you like the new health to be?");
                        string healthString = Console.ReadLine();

                        while (!int.TryParse(healthString, out health))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            healthString = Console.ReadLine();
                        }
                        break;

                    case 4:
                        Console.WriteLine("What would you like the new age to be?");
                        string ageString = Console.ReadLine();

                        while (!int.TryParse(ageString, out age))
                        {
                            Console.WriteLine("Please type only integers, then press enter.");
                            ageString = Console.ReadLine();
                        }
                        break;

                    case 5:
                        Console.WriteLine("What would you like the new gender to be?");
                        gender = Console.ReadLine();

                        break;


                }




            }


            Console.WriteLine(" ");
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        


    }

        public static void displayCharacter()
        {
            Console.WriteLine("The name of the character is "+name+ ".");
            Console.WriteLine("The baseAttack of the character is " + baseAttack + ".");
            Console.WriteLine("The health of the character is " + health + ".");
            Console.WriteLine("The age of the character is " + age + ".");
            Console.WriteLine("The gender of the character is " + gender + ".");
            Console.WriteLine("The equipped weapon of the character is " + weaponName + ".");



            Console.WriteLine(" ");
            Console.WriteLine("Press any key to continue");
            Console.ReadLine();
        }

     

    }

    
}


