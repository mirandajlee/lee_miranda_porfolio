﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    abstract class Item : Iusable
    {


        public abstract void use(Character mainCharacter);



        //implements Iusable interface with abstract keyword

         static int intEffect;
         static string strEffect;
         static string description;

       


        //getters and setters
        public int getIntEffect()
        {
            return intEffect;
        }

        public void setIntEffect(int _intEffect)
        {
            intEffect = _intEffect;
        }

        public string getStrEffect()
        {
            return strEffect;
        }

        public void setStrEffect(string _strEffect)
        {
            _strEffect = strEffect;
        }

        public string getDescription()
        {
            return description;
        }

        public void setDescription(string _description)
        {
            _description = description;
        }

        
    }
}
