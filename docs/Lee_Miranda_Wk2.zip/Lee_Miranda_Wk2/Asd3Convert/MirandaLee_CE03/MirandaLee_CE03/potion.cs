﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    class potion : Item
    {
        private static int intEffect;
        private static string strEffect;
        private static string description;


        public potion(int _intEffect, string _strEffect, string _description)
        {
            intEffect = _intEffect;
            strEffect = _strEffect;
            description = _description;
        }

        public override void use(Character mainCharacter)
        {
            if (strEffect == Character.statusEffect)
            {
                Character.statusEffect = null;
            }
            else if (strEffect == "all")
            {
                mainCharacter = null;
            }
                
        }





    }
}
