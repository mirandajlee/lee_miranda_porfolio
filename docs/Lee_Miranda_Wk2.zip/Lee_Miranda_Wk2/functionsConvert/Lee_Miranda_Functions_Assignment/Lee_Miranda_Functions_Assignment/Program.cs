﻿using System;

namespace loops
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*Miranda Lee
			 * Section 2
			 * November 17 2015
			 * Functions Assignment
			 */

			//We are going to make a calculator to see how much money you can save 

			//tell the user what we are doing. 

			Console.WriteLine ("Hello! Lets see how much money you can save! Please enter your annual salary. Please enter only integers.");
			//capture the response
			string salarystring = Console.ReadLine ();

			//create variable to hold the converted response.
			double salary;

			//make sure that the user entered the correct response.
			while (!double.TryParse (salarystring, out salary)) {
				//alert user to error
				Console.WriteLine("It looks like you entered something other then integers, try again.");
				//recapture the users response
				salarystring = Console.ReadLine ();
			}
			//thank the user for entry and relay what the salary is. 
			Console.WriteLine ("Thank you, your annual salary is ${0}. please enter the amount of your monthly bills, only integers once again.",salary);

			//capture the response
			string monthlyBillsString = Console.ReadLine ();

			//create variable to hold the converted response.
			double monthlyBills;

			//make sure that the user entered the correct response.
			while (!double.TryParse (monthlyBillsString, out monthlyBills)) {
				//alert user to error
				Console.WriteLine("It looks like you entered something other then integers, try again.");
				//recapture the users response
				monthlyBillsString = Console.ReadLine ();
			}

			//catch the annual bills method 
			double annualBills = calcYearlyBills(salary, monthlyBills);

			//tell the user the outcome of their yearly bills. 
			Console.WriteLine ("Thank you, your annual bills total $"+annualBills+" Now let's see how much you can save each year.");

			//catch the yearly excess method
			double yearlyExtra = calcYearlyExcess(salary,annualBills);

			//tell the user the outcome of their excess. 
			Console.WriteLine("After looking at your salary and your annual bills, you have ${0} leftover each year!", yearlyExtra);


			//create loop to see how long it would take to save 1 million dollars. 
			//create variable for years and savings in lifetime.
			int years = 2;
			double lifeTimeSavings;

			while (years <=10){

				lifeTimeSavings = yearlyExtra * years;
				//tell the user how much they can save.	
				Console.WriteLine ("You can save ${0} in {1} years.", lifeTimeSavings,years);

				years += 2;
			}










		}

		public static double calcYearlyBills (double annualSalary, double monthlyBills){

			//created method to calculate yearly bills. 
			//create variable
			double annualBills;

			//calculate annual bills
			annualBills = monthlyBills * 12;

			//return annual bills to main
			return annualBills;


		}







		public static double calcYearlyExcess (double annualSalary, double annualBills){

			//calculate yearly excess.
			double yearlyExcess = annualSalary-annualBills;

			//return to main
			return yearlyExcess;

		}


	}
	/* I tested a LOT of things for this calculator, I struggled through the while loop for the life times savings so I tested it a lot. First I entered 45000 annual 
	 * income, and 2000 monthly bills.I got that I have 24,000 annual bills and I got 21,000 leftover yearly.  I got that I would save 42,000 in 2 years and 84,000 in 4.
	 * 126000 in 6, 168,000 in 8 and 210,000 in 10 years! I tested these on a calculator and recieved the same answers.
*/
}
