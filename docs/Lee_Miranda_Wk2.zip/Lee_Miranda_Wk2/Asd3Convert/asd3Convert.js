



newMainCharacter = new Character("", 0, "");


var userChoice;
var name;
var health;
var statusEffect;
var intEffect;
var strEffect;
var description;
var newStatus;
var newPotion;





    while (userChoice != "exit")
    {
        userChoice = prompt("What would you like to do? \n\n 1- Create a new character \n 2- Give the character a status effect \n 3- Use a potion on the Character\n 4- Use a StatusMedicine on the Character \n 5- Display character stats \n 6- Exit\n\n Please type your choice or the correlated number and press enter.");

        switch ((userChoice).valueOf().toLowerCase()) {
            case "Create a new character":
            case "1" :

                SetCharacter();

            break;
            case "Give the character a status effect":
            case "2" :
                    StatusEffect = prompt("What would you like to set at the StatusEffect for the character? Please enter characters.");
                break;


            case "Use a potion on the Character":
            case "3":
                    NewPotion();
                break;
            case "Use a StatusMedicine on the Character":
            case "4":
                    SetStatusMedicine();
               break;
            case "Display character stats":
            case "5":
                    if (mainCharacter != null) {
                        DisplayCharacter();

                    }
                    else {
                        alert("There is currently no character set.");
                    }
                break;

            case "Exit" :
            case "6":
                    window.close();
               break;
            default:

                    alert("Please enter the choice, or the correlated number and press enter.\r\n");

        }
    }


//create character
function SetCharacter()
{


    name = prompt("What would you like the character name to be?");


    health = prompt("What would you like the character's health to be? Please enter only integers.");


    statusEffect = prompt("What would you like the character's status Effect to be?");


    mainCharacter = new Character(name, health, statusEffect);


    alert("Your new character has been set, " + name + " has a health of " + health + ", and a status effect of " + statusEffect + ". \nWhat would you like to do next? Press any key to continue.");
}

//status medicine
function SetStatusMedicine()

{


    if (mainCharacter != null)
    {


        intEffect = prompt("What would you like the effect of the medicine to be? Enter only integers please.");

        strEffect = prompt("What is the name of your medicine?");

        description = prompt("What is the description of your medicine?");


        newStatus = new StatusMedicine(intEffect, strEffect, description);
        UseStatusMedicine(mainCharacter);

        alert("The status medicine has been set to " + strEffect + " ,your medicine has an effect of " + intEffect + ", and the description of your medicine is " + description + ". The medicine changed your characters health to " + health + ". Press any key to continue.");



    }else
    {
        alert("There is currently not a character set. Press any key to continue.");
    }






}

//create potion
function NewPotion()

{



    if (mainCharacter != null)
    {
        intEffect = prompt("What would you like the intEffect to be? Please enter integers.");
        strEffect = prompt("What would you like the strEffect to be? Please enter characters.");
        description = prompt("What would you like the description to be? Please enter characters.");

        newPotion = new Potion(intEffect, strEffect, description);

        //use potion on the character

        UsePotion(mainCharacter);
        alert("Your potion has an effect of " + intEffect + ", a string effect of" + strEffect + " and a description of " + description + ".");



    }
    else
    {
        alert("There is no character set.");
    }


}

function Potion(_intEffect, _strEffect, _description)
{
    intEffect = _intEffect;
    strEffect = _strEffect;
    description = _description;
}
function Character(_name, _health, _statusEffect)
{
     name = _name;
     health = _health;
     statusEffect = _statusEffect;
}

function UsePotion( mainCharacter)
{
    if (strEffect == Character.statusEffect)
    {
        Character.statusEffect = null;
    }
    else if (strEffect == "all")
    {
        mainCharacter = null;
    }

}
function UseStatusMedicine(Character) {
    var newHealth;
    newHealth = intEffect + health;

    newHealth = health;

}
function StatusMedicine(_intEffect, _strEffect, _description)
{
    intEffect = _intEffect;
    strEffect = _strEffect;
    description = _description;
}
function DisplayCharacter()
{

    alert("The characters stats are currently: \r Name: " + name + "\r Health: " + health + "\r Status Effect:" + statusEffect + "\r Press any key to continue.");



}