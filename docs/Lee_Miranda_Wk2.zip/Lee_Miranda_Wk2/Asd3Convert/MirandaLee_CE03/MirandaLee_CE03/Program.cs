﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    class Program
    {
        private static Character mainCharacter;

        

        Character newMainCharacter = new Character("", 0, "");


        private static string userChoice;

        static void Main(string[] args)
        { 
            int intUserChoice;



            


            while (userChoice != "exit")
            {
                Console.WriteLine("What would you like to do? \n\n 1- Create a new character \n 2- Give the character a status effect \n 3- Use a potion on the Character\n 4- Use a StatusMedicine on the Character \n 5- Display character stats \n 6- Exit\n\n Please type your choice or the correlated number and press enter.");
                userChoice = Console.ReadLine();
                Int32.TryParse(userChoice, out intUserChoice);



                if (string.Compare(userChoice, "Create a new character", true) == 0)
                {
                    setCharacter();
                }
                else if (intUserChoice == 1)
                {
                    setCharacter();
                }
                else if (string.Compare(userChoice, "Give the character a status effect", true) == 0)
                {
                    Console.WriteLine("What would you like to set at the StatusEffect for the character? Please enter characters.");
                    Character.statusEffect = Console.ReadLine();
                }
                else if (intUserChoice == 2)
                {
                    Console.WriteLine("What would you like to set at the StatusEffect for the character? Please enter characters.");
                    Character.statusEffect = Console.ReadLine();
                }
                else if (string.Compare(userChoice, "Use a potion on the Character", true) == 0)
                {
                    newPotion();
                }
                else if (intUserChoice == 3)
                {
                    newPotion();
                }
                else if (string.Compare(userChoice, "Use a StatusMedicine on the Character", true) == 0)
                {
                    setStatusMedicine();
                }
                else if (intUserChoice == 4)
                {
                    setStatusMedicine();
                }
                else if (string.Compare(userChoice, "Display character stats", true) == 0)
                {
                    if (mainCharacter != null)
                    {
                        mainCharacter.displayCharacter();

                    }
                    else
                    {
                        Console.WriteLine("There is currently no character set.");
                    }
                }
                else if (intUserChoice == 5)
                {
                    if (mainCharacter != null)
                    {
                        mainCharacter.displayCharacter();

                    }
                    else
                    {
                        Console.WriteLine("There is currently no character set.");
                    }
                }
                else if (string.Compare(userChoice, "Exit", true) == 0)
                {
                    Environment.Exit(0);
                }
                else if (intUserChoice == 6)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Please enter the choice, or the correlated number and press enter.\r\n");
                }
            }
        }

        //create character

            public static void setCharacter()
        {
            string name;
            int health;
            string statusEffect;
           
            Console.WriteLine("What would you like the character name to be?");
            name = Console.ReadLine();

            Console.WriteLine("What would you like the character's health to be? Please enter only integers.");
            while (true)
            {
                string userInput = Console.ReadLine();
                try
                {
                    health = Convert.ToInt32(userInput);


                    break;
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Please only enter numbers.", e);
                }

            }


            Console.WriteLine("What would you like the character's status Effect to be?");
            statusEffect = Console.ReadLine();

            mainCharacter = new Character(name, health, statusEffect);
           

            Console.WriteLine("Your new character has been set, " + name + " has a health of " + health + ", and a status effect of " + statusEffect + ". \nWhat would you like to do next? Press any key to continue.");
            Console.ReadLine();
        }

        //status medicine
        public static void setStatusMedicine()
          
        {
            int intEffect;
            string strEffect;
            string description;

            if (mainCharacter != null)

            {
                Console.WriteLine("What would you like the effect of the medicine to be? Enter only integers please.");

                while (true)
                {
                    string userInput = Console.ReadLine();
                    try
                    {
                        intEffect = Convert.ToInt32(userInput);


                        break;
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine("Please only enter numbers.", e);
                    }

                }

                Console.WriteLine("What is the name of your medicine?");
                strEffect = Console.ReadLine();

                Console.WriteLine("What is the description of your medicine?");
                description = Console.ReadLine();

                StatusMedicine newStatus = new StatusMedicine(intEffect, strEffect, description);
                newStatus.use(mainCharacter);

                Console.WriteLine("The status medicine has been set to " + strEffect + " ,your medicine has an effect of " + intEffect + ", and the description of your medicine is " + description + ".");
                Console.WriteLine("The medicine changed your characters health to " + StatusMedicine.characterHealth + ". Press any key to continue.");
                Console.ReadLine();


            }else
            {
                Console.WriteLine("There is currently not a character set. Press any key to continue.");
                Console.ReadLine();
            }

         

            

           
        }


        


        //create potion

        public static void newPotion()

        {
            int intEffect;

            if (mainCharacter != null)
            {
                Console.WriteLine("What would you like the intEffect to be? Please enter integers.");
              
                while (true)
                {
                    string userInput = Console.ReadLine();
                    try
                    {
                         intEffect = Convert.ToInt32(userInput);


                        break;
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine("Please only enter numbers.", e);
                    }

                }


                Console.WriteLine("What would you like the strEffect to be? Please enter characters.");
                string strEffect = Console.ReadLine();

                Console.WriteLine("What would you like the description to be? Please enter characters.");
                string description = Console.ReadLine();


                potion newPotion = new potion(intEffect, strEffect, description);

                //use potion on the character

                newPotion.use(mainCharacter);
                Console.WriteLine("Your potion has an effect of " + intEffect + ", a string effect of" + strEffect + " and a description of " + description + ".");
                

                
            }
            else
            {
                Console.WriteLine("There is no character set.");
            }

            Console.ReadLine();
        }

 
        
          

           
        

        
        
        }

   

        
    }

