﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lee_Miranda_Class_Object_Assignment
{
    class cat
    {

        //create member variables

        string color;
        int age;
        int weight;
        bool status;

        //create constructors

        public cat(string _color, int _age, int _weight, bool _status)
        {
            _color = color;
            _age = age;
            _weight = weight;
            _status = status;
        }

        //getters and setters

        public string getColor()
        {
            return color;
        }

        public void setColor(string _color)
        {
            color = _color;
        }

        public int getAge()
        {
            return age;
        }

        public void setAge(int _age)
        {
            age = _age;
        }

        public int getWeight()
        {
            return weight;
        }

        public void setWeight(int _weight)
        {
            weight = _weight;
        }

        public bool getStatus()
        {
            return status;
        }

        public void setStatus(bool _status)
        {
            status = _status;
        }
    }
}
