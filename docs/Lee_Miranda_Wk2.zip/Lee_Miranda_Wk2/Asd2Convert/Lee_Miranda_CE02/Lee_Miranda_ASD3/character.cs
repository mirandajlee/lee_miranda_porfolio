﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lee_Miranda_ASD3
{
    class character
    {
        //create variables

        private static string name;
        private static int baseAttack;
        private static int health;
        private static weapon equippedWeapon;
        private static int age;
       private static string gender;

        //constructor
        public character(string _name, int _baseAttack, int _health, int _age, string _gender)
        {
            _name = name;
            _baseAttack = baseAttack;
            _health = health;
            _age = age;
            _gender = gender;

        }

        //getters

        public string getName()
        {
            return name;
        }
        public int getBaseAttack()
        {
            return baseAttack;
        }
        public int getHealth()
        {
            return health;
        }

        
        public int getAge()
        {
            return age;
        }
        public string getGender()
        {
            return gender;
        }
       
        //setters
        public void setName(string _name)
        {
            _name = name;
        }   
        public void setBaseAttack(int _baseAttack)
        {
            _baseAttack = baseAttack;
        }
        public void setHealth(int _health)
        {
            _health = health;
        }
        public void setAge(int _age)
        {
            _age = age;
        }
        public void setGender(string _gender)
        {
            _gender = gender;
        }
    
    }
}
