

var salary;
var monthlyBills;
var annualBills;
var yearlyExtra;

			 salary = prompt("Hello! Lets see how much money you can save! Please enter your annual salary. Please enter only integers.");



			//thank the user for entry and relay what the salary is. 
			monthlyBills = prompt("Thank you, your annual salary is $"+salary+". please enter the amount of your monthly bills, only integers once again.");



			//catch the annual bills method 
			annualBills = calcYearlyBills(monthlyBills);

			//tell the user the outcome of their yearly bills. 
			alert("Thank you, your annual bills total $"+annualBills+" Now let's see how much you can save each year.");

			//catch the yearly excess method
			yearlyExtra = calcYearlyExcess(salary,annualBills);

			//tell the user the outcome of their excess. 
			alert("After looking at your salary and your annual bills, you have $"+ yearlyExtra + " leftover each year!");


			//create loop to see how long it would take to save 1 million dollars. 
			//create variable for years and savings in lifetime.
			var years = 2;
			var lifeTimeSavings;

			while (years <=10){

				lifeTimeSavings = yearlyExtra * years;
				//tell the user how much they can save.	
				alert("You can save $"+lifeTimeSavings+ " in "+years+" years.");

				years += 2;
			}



		function calcYearlyBills (monthlyBills){

			//created method to calculate yearly bills. 
			//create variable
			var annualBills;

			//calculate annual bills
			annualBills = monthlyBills * 12;

			//return annual bills to main
			return annualBills;


		}







		function calcYearlyExcess (annualSalary, annualBills) {

            //calculate yearly excess.
            var yearlyExcess;

            yearlyExcess = annualSalary - annualBills;

            //return to main
            return yearlyExcess;
        }
