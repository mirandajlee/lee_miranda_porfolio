﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lee_Miranda_ASD3
{
    class weapon
    {
        //member variables
       private static int attack;
       private static string weaponName;

        //constructor
        public weapon (int _attack, string _weaponName)
        {
            _attack = attack;
            _weaponName = weaponName;
        }

        //getters and setters
        public int getAttack()
        {
            return attack;
        }

        public void setAttack(int _attack)
        {
            attack = _attack;
        }

        public string getWeaponName()
        {
            return weaponName;
        }

        public void setWeaponName(string _weaponName)
        {
            weaponName = _weaponName;
        }
    
    }
}
