var attack;
var weaponName;
var name;
var baseAttack;
var health;
var age;
var gender;
var userChoice;







    //User options

    while (userChoice != "exit") {
        userChoice = prompt("Would you like to: \r\n 1.) Create a character \r\n 2.) Modify Character \r\n 3.) Create and Equip Weapon \r\n 4.) Display Character Data \r\n 5.) Exit \r\n Enter the corresponding number or the choice.");


        switch ((userChoice).valueOf().toLowerCase()) {

            case "create a character":
            case "1":

                CreateCharacter();

                break;

            case "modify character":
            case "2":

                ModifyCharacter();
                break;
            case "create and equip weapon":
            case "3":

                NewWeapon();
                break;
            case "display character data":
            case "4":

                DisplayCharacter();
                break;

            case "exit":
            case "5":

                window.close();

                break;
            default:
                alert("Please enter a valid response.");

        }

    }

//functions


function CreateCharacter()
{

    name = prompt("What is the name of your character?");
    baseAttack = prompt("What is the baseAttack of your character?");
    health = prompt("What is the health of your Character?");
    age = prompt("What is the age of your character?");
    gender = prompt("What is the gender of your character?");


    mainCharacter = new Character(name, baseAttack, health, age, gender);


    baseCharacter = mainCharacter;



    alert("Press any key to continue");



}

function NewWeapon()
{



    attack = prompt("What is the attack of your new Weapon?");
   weaponName = prompt("What is the name of your new weapon?");


    NewWeapon = new Weapon(attack, weaponName);



    alert("The " + weaponName + " is the equipped weapon.\r Press any key to continue.");



}

function ModifyCharacter()
{
    var modifyResponse;


    if (baseCharacter == null)
    {
        alert("The Character does not currently exist.");
    }
    else

    {
        modifyResponse = prompt("Which option would you like to modify for "+name+ "? \n 1- Name \n 2- baseAttack \n 3- health \n 4- age \n 5- gender");

        switch (modifyResponse)
        {
            case "Name":
            case "1":


                name = prompt("What would you like the new name to be?");

                break;
            case "baseAttack":
            case "2":
                baseAttack = prompt("What would you like the new baseAttack to be?");


                break;
            case "health":
            case "3":
                health = prompt("What would you like the new health to be?");


                break;
            case "age":
            case "4":
               age = prompt("What would you like the new age to be?");


                break;
            case "gender":
            case "5":
                gender = prompt("What would you like the new gender to be?");

                break;
        }



        }








    alert("Press any key to continue");




}

function DisplayCharacter()
{
    alert("The name of the character is "+name+ ". The baseAttack of the character is " + baseAttack + ". The health of the character is " + health + ". The age of the character is " + age + ". The gender of the character is " + gender + ". The equipped weapon of the character is " + weaponName + ".");

}
function Character(_name, _baseAttack, _health, _age, _gender)
{
    _name = name;
    _baseAttack = baseAttack;
    _health = health;
    _age = age;
    _gender = gender;

}
function Weapon (_attack, _weaponName)
{
    _attack = attack;

    _weaponName = weaponName;

}
