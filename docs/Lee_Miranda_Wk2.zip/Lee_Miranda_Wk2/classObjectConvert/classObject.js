var color;
var age;
var weight;
var status;

alert("Let's make a cat! ");

color = prompt("What color is your cat? ");


age = prompt("How old is your cat? ");


weight = prompt("How much does your cat weigh? ");


status = prompt("Is your cat an outside cat? Enter true or false. ");





firstPerson = new Cat(color, age, weight, status);


alert("Your cat is " + color + " in color. Your cat is " + age + " years old. Your cat weighs " + weight + " pounds.");


if (status == false)
{
    alert("Your cat is an inside cat.");

}
else
{
    alert("Your cat is a outside cat.");

}

function Cat(color, age, weight, status)
{

}



