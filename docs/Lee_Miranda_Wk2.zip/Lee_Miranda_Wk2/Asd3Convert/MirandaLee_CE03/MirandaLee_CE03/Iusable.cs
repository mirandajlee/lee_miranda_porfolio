﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    interface Iusable
    {
        void use(Character mainCharacter);
        
       
    
    }
}
