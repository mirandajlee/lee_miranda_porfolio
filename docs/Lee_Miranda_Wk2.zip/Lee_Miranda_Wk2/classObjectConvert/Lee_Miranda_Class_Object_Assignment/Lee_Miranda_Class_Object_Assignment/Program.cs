﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lee_Miranda_Class_Object_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            string color;
            int age;
            int weight;
            bool status;

            Console.WriteLine("Let's make a cat! ");

            Console.Write("What color is your cat? ");
            color = Console.ReadLine();

            Console.Write("How old is your cat? ");
            age = Convert.ToInt32(Console.ReadLine());

            Console.Write("How much does your cat weigh? ");
            weight = Convert.ToInt32(Console.ReadLine());

            Console.Write("Is your cat an outside cat? Enter true or false. ");
            status = Convert.ToBoolean(Console.ReadLine());




            cat firstPerson = new cat(color, age, weight, status);


            Console.WriteLine("Your cat is " + color + " in color.");
            Console.WriteLine("Your cat is " + age + " years old.");
            Console.WriteLine("Your cat weighs " + weight + " pounds.");
           
            if (status == false)
            {
                Console.WriteLine("Your cat is an inside cat.");

            }
            else
            {
                Console.WriteLine("Your cat is a outside cat.");

            }



            Console.ReadLine();

            }
                


           
        
    }
}
