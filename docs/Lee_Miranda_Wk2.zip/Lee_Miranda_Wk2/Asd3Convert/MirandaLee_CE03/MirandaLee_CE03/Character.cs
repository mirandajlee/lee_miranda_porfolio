﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MirandaLee_CE03
{
    class Character
    {
         public static string name;
         public static int health;
         public static string statusEffect;


        public void use(string Character)
        {

        }

        

        //constructor

        public Character(string _name, int _health, string _statusEffect)
        {
            _name = name;
            _health = health;
            _statusEffect = statusEffect;
        }

        //getters setters

        public string getName()
        {
            return name;
        }
        public void setName(string _name)
        {
            name = _name;
        }

        public int getHealth()
        {
            return health;
        }
        public void setHealth(int _health)
        {
            health = _health;
        }
        public string getStatusEffect()
        {
            return statusEffect;
        }
        public void setStatusEffect(string _statusEffect)
        {
            statusEffect = _statusEffect;
        }

        public void displayCharacter()
        {
          
                Console.WriteLine("The characters stats are currently: \r\n Name: " + name + "\r\n Health: " + health + "\r\n Status Effect:" + statusEffect + "\r\n");
                Console.WriteLine("Press any key to continue.");
                Console.ReadLine();

           
        }
    }
}
