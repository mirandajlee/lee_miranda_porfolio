var name;
var paycheck;
var bills;
var spendingMoney;
var likeMakeup;

name = prompt("What is your name?");
likeMakeup = prompt("Nice to meet you " + name + "! Do you have an obsession with Makeup? Please enter yes or no.");



	if (likeMakeup == "no") {
		alert("Well then we are done here.");

	}
	else if (likeMakeup == "yes") {

		paycheck = prompt("Well then, Let's see if you can buy the new Jeffree Starr Palette! \r How much was your paycheck?");
		bills = prompt("You've been working hard! How much are your bills?");

		spendingMoney = paycheck - bills;

		if (spendingMoney >= 100) {

			alert("Get on over to JeffreeStarrCosmetics.com and buy that palette!");

		} else if (spendingMoney >= 50 && spendingMoney <= 100) {

			alert("You only have $" + spendingMoney + " after your bills, but you can still afford the palette");

		} else if (spendingMoney < 50) {

			alert("It looks like your budget is too tight right now, save up and pick up that palette ASAP!");

		}

	}

	else {
		likeMakeup = prompt("Please enter only yes or no.");

	}


